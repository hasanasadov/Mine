#include "Triangle.h"

Triangle::Triangle(){sidee=0;}
Triangle::Triangle(double a){sidee=a;}