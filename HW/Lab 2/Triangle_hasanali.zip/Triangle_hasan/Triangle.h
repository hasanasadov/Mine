#ifndef TRIANGLE_H
#define TRIANGLE_H
#pragma once
#include <math.h>
class Triangle {
    double sidee;
    public:
        Triangle();
        Triangle(double a);
        double area (){return (sidee*sidee*sqrt(3)/4);}
        double peri(){return (3*sidee);}
};
#endif