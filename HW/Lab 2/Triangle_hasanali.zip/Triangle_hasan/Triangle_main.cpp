#include <iostream>
#include "Triangle.cpp"
#include <math.h>
using namespace std;
int main(){
    Triangle t1;
    Triangle t2(5);
    cout << "Here is the Triangle's data:\n";
    cout << "T1 Side: " << t1.sidee() << endl;
    cout << "T1 Perimeter: " << t1.peri() << endl;
    cout << "T1 Area: " << t1.area() << endl;
    cout << "T2 Side: " << t2.sidee() << endl;
    cout << "T2 Perimeter: " << t2.peri() << endl;
    cout << "T2 Area: " << t2.area() << endl;
}