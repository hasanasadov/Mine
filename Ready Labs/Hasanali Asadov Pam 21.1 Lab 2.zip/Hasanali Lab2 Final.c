//ASADOV HASANALI PAM21.1

#include <stdio.h>
#include <string.h>
#include <math.h>
//Task3
/*
int main(){
    int a,count;
    float summ;
    scanf("%d",&a);
    summ=0;
    count=0;
    while(a!=-1){
        summ+=a;
        count+=1;
        scanf("%d",&a);
    }
    printf("summ=%2.f",summ);
    printf("count=%d",count);
    printf("average=%f",summ/count);
    return 0;
}
*/

//Task4
/*
int main(){
    char a;
    printf("enter the letter");
    scanf("%c",&a);
    switch(a){
        case 'a':case 'i':case 'e':case 'o':case 'u':
            printf("the letter is wovel\n");
            break;
        default:
            printf("the letter is consonant\n");
            break;
    }
    return 0;
}
*/

//Task5
/*
int main(){
    char c;
    printf("enter the letter");
    scanf("%c",&c);
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')){
        printf("%c is an alphabet.", c);}
    else{
        printf("%c is not an alphabet.", c);
    }
    return 0;
}
*/

//Task6
/*
int main() {
    int a,b,c,minimum;
    scanf("%d %d",&a,&b);
    if (a>b){
        minimum=b;}
    else{
        minimum=a;}
    int x=1;
    while (x<=minimum){
        if (a%x==0 && b%x==0)
            c=x;
        x++;
    }
    printf("%d",a*b/c);
}
*/


//Task7
/*
int main(){
    int a,b,s;
    printf("enter the number");
    scanf("%d",&a);
    printf("enter the power");
    scanf("%d",&b);
    s=1;
    while(b!=0){
        s=s*a;
        b-=1;
    }
    printf("power of number is %d",s);
    return 0;
}
*/

//Task8
/*
int len(){
    int a,x,temporary,summary;
    printf("enter the number:\n");
    scanf("%d",&a);
    printf("a=%d\n",a);
    temporary=a;
    summary=0;
    while (temporary>0){
        x=temporary%10;
        summary=summary*10+x;
        temporary=temporary/10;
    }
    if (a==summary){
        printf("%d is palindrome",a);
    }
    else{
        printf("%d is not palindrome",a);
    }
    return 0;
}
*/

//Task 9
/*
int main (){
    int account_number,mortgage_amount,mortgage_term,mpi,tap;
    float ir,tip; 
    printf("enter account number:");
    scanf("%d",&account_number);
    printf("enter mortgage amount(in dollars):");
    scanf("%d",&mortgage_amount);
    printf("enter mortgage term(in year):");
    scanf("%d",&mortgage_term);
    printf("enter innterest rate(as a decimal):");
    scanf("%f",&ir);
    tip=mortgage_amount*ir*mt;
    tap=tip+mortgage_amount;
    mpi=tap/(mortgage_term*12);
    printf("The monthly payable interest is $%d",mpi);
    return 0;
}
*/

//Task 10
/*
int main(){
    int counter=0,n=0,largest=0;
    for (counter;counter<10; counter++){
        printf("enter:");
        scanf("%d",&n);
        if (n>largest){
            largest=n;
        }
    }
    printf("The largest is=%d",largest);
    return 0;
}
*/

//Task 11
/*
int main(){
    int n,n2,n3,n4;
    n=1;
    printf("N\t N^2\t N^3\t N^4\n");
    while (n<=10){
        n2=n*n;
        n3=n*n*n;
        n4=n*n*n*n;
        printf("%d\t %d\t %d\t %d\t",n,n2,n3,n4);
        printf("\n");
        n++;
    }
    return 0;
}
*/

//Task 12(While format)(as question)
/*
int main(void){
    int x=1,total=0;
    while (x<=5){
        total+=x*x;
        printf("%d\n",x*x);
        ++x;
    }
    printf("Total is %d\n",total);
    return 0;
}
*/

//Task 12(For format)
/*
int main(void){
    int x=1,total=0;
    for (int x=1; x<=5;x++){
        total+=x*x;
        printf("%d\n",x*x);
    }
    printf("Total is %d\n",total);
    return 0;
}
*/

//Task 13(While format)(as question)
/*
int main (void){
    int oc=1;
    while (oc<=10){
        int ic=1;
        while (ic<=oc){
            printf("*");
            ic++;
        }
        printf("\n");
        oc++;
    }
    return 0;
}
*/

//Task 13(For format)
/*
int main(void){
    for (int oc=1;oc<=10;oc++){
        for (int ic=1;ic<=oc;ic++){
            printf("*");
        }
        printf("\n");
    }
    return 0;
}
*/

//Task 14
/*
int main(){
    int a,temp,temp2,summ=0,d;
    int c=0;
    scanf("%d",a);
    temp=a;
    while (temp>0){
        temp/=10;
        c++;
    }
    printf("%d",c);
    while(temp2>0){
        d=pow(temp2%10,c);
        summ+=d;
        temp2/=10;
    }
    printf("%d",summ);
    if(a==summ){
        printf("The Number is Armstrong number");
    }
    else{
        printf("The Number is not Armstrong number");
    }
    return 0;
}
*/

//Task 15
/*
int main(){
    int count1=0,count2=0,a,temp,x;
    printf("enter: \n");
    scanf("%d",&a);
    printf("a=%d\n",a);
    temp=a;
    while (t>0){
        t/=10;
        count1++;
    }
    while (count1>0){
        x=a%10;
        a/=10;
        if (x==9){
            count2++;
        }
        count1--;
    }
    printf("%d digits of the number is 9",count2);
    return 0;
}
*/

//Task 16(a)
/*
int main(){
    int n,multp=1,temp;
    printf("number factorial: \n");
    scanf("%d",&n);
    printf("n=%d\n",n);
    temp=n;
    if (n>0){
        while (temp>0){
            multp*=temp;
            temp--;
        }
        printf("%d! is %d",n,multp);
    }
    else if (n==0){
        printf("%d! is 0",n);
    }
    return 0;
}
*/

//Task 17
//Its easy

//Task 18
/*
int main(){
    int a,s=0,A;
    A=a
    scanf("%d",&a);
    if(a%10>3){
        s=s+(a+7)%10;
    }
    else{
        s+=(a+7);
    }
    a/=10;
    if(a%10>3){
        s=s+((a+7)%10)*10;
    }
    else{
        s+=(a+7)*10;
    }
    a/=10;
    if(a%10>3){
        s=s+((a+7)%10)*100;
    }
    else{
        s+=(a+7)*100;
    }
    a/=10;
    if(a%10>3){
        s=s+((a+7)%10)*1000;
    }
    else{
        s+=(a+7)*1000;
    }
    printf("coded %d is %d",A,s);
    return 0;
}
*/

//TO LOOPS FINISHED

//FROM LOOPS STARTED
#include <stdio.h>
//Task 20
/*
int main(void){
    int x,i,j;
    printf("%s","Enter an integer in range 1-20:");
    scanf("%d",&x);
    for(i=1;i<=x;i++){
        for(j=1;j<=x;j++){
            if(j==i)
                printf("%c",'@');
            else
                printf(" ");    
        }
        printf("\n");
    }
}
*/

//Task 21(1)
/*
int main(){
    int a=1;
    while (a!=11){
        printf("%d\n",a);
        a++;
    }
    return 0;
}
*/

//Task 21(2)
/*
int main(){
    for(int a=1;a<=10;a++){
        printf("%d\n",a);
    }
    return 0;
}
*/

//Task 22
/*
int main(){
    int s=1,a;
    printf("Number\t Factorial\n");
    for(int a=1;a<=5;a++){
        s=s*a;
        printf("%d\t %d\n",a,s);
    }
    return 0;
}
*/

//Task 23
/*
int main(){
    int counter;
    for(int a=2;a<=100;a++){
        for(int c=2;c<a;c++){
            if (a%c==0){
                counter++;
                    }
        }
        if (counter==0){
            printf("%d\n",a);
            }
        counter=0;
        }
}
*/

//Task 24
/*
int main(){
    int a;
    scanf("%d",&a);
    while(a!=0){
        printf("%d",a%10);
        a/=10;
    }
}
*/

//Task 25
/*
int main(){
    int N;
    scanf("%d",&N);
    printf("even numbers 1 to %d\n",N);
    for(int a=2;a<=N;a++){
        if (a%2==0)
            printf("%d ",a);
    }
}
*/

//Task 26
/*
int main(){
    int a;
    scanf("%d",&a);
    switch(a){
        case 1:
            printf("Monday");
            break;
        case 2:
            printf("Tuesday");
            break;
        case 3:
            printf("Wednesday");
            break;
        case 4:
            printf("Thursday");
            break;
        case 5:
            printf("Friday");
            break;
        case 6:
            printf("Saturday");
            break;
        case 7:
            printf("Sunday");
            break;
    default:
        printf("there is not such a day in week");
            break;
    }
}
*/

//Task 27
/*
int main(){
    int a,b;
    printf("Input first number: \n");
    scanf("%d",&a);
    printf("Input second number:n");
    scanf("%d",&b);
    if (a>b)
        printf("Maximum is %d\n",a);
    else
        printf("Maximum is %d\n",b);
}
*/

//Task 28
/*
int main(){
    int a;
    printf("Input number: \n");
    scanf("%d",&a);
    if (a%2==0)
        printf("Even Number \n");
    else
        printf("Odd Number \n");
}
*/

//Task 29(a)
/*
int main(){
    int s=0,c=0;
    for(int a=1;a<=99;a++){
        if (a%2==1){
            s+=a;
            c++;
            }
    }
    printf("sum=%d count=%d",s,c);
}
*/

//Task 29(c)
/*
#include<math.h>
int main(){
    float a;
    a=pow(2.5,3);
    printf("%f",a);
}
*/

//Task29(d)
/*
int main(){
    for(int a=1;a<=20;a++){
        if (a%5==0){
            printf("%d ",a);
            printf("\n");
        }
        else{
            printf("%d ",a);
        }
    }
}
*/

//Task30
/*
int main(){
    float c,f;
    printf("enter C: \n");
    scanf("%f",&c);
    f=1.8*c + 32;
    printf("%f C=%f F",c,f);
}
*/

//Task 31
/*
int main(){
    int s=7;
    printf("7");
    for(int a=8;a<=100;a++){
        if (a%7==0){
            printf("+%d",a);
            s+=a;
        }
    }
    printf("=%d",s);
}
*/


//Optional questions - advanced version

//Task 32
/*
#include <stdio.h>
void main(){    
    int n; 
	scanf("%d",&n);
	printf("Decimal value = %d\n",n); 
	printf("Octal value = %o\n",n); 
	printf("Hexadecimal value = %n",n); 
} 
*/

//Task 33
/*
int main(){
    int i,den;
    double pi=4;
    for (i=0; i<10000;i++){
        den=i*2+3;
        if (i%2==0){
            pi=pi-(4.0/den);
        }
        else{
            pi=pi+(4.0/den);
        }
    }
    printf("pi = %lf\n",pi);
}
*/