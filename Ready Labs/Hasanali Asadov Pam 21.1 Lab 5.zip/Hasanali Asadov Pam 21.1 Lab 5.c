#include <stdio.h>

//Task 2
/*
#define S 80
size_t mystery2(const char *s);
int main(void){
    char string[S];
    puts ("Enter a string:");
    scanf("%79s",string);
    printf("%d\n",mystery2(string));
}

size_t mystery2(const char *s){
    size_t x;
    for (x=0; *s !='\0';++s){
        ++x;
    }
    return x;
}
*/

//Task 3
/*
#define S 80
int mystery3(const char *s1,const char *s2);
int main(){
    char string1[S];
    char string2[S];
    puts("Enter the strings:");
    scanf("%79s%79s",string1,string2);
    printf("The result is %d\n",mystery3(string1,string2));
}
int mystery3(const char *s1,const char *s2){
    int result=1;
    for (; *s1 !='\0' && *s2!='\0';++s1,++s2){
        if (*s1!=*s2){
            result=0;
        }
    }
    return result;
}
*/

//Task 4(1)
/*
void fun(int x){
    x=30;
}
int main(){
    int y=20;
    fun(y);
    printf("%d",y);
    return 0;
}
*/

//Task 4(2)
/*
void fun(int *ptr){
    *ptr=30;
}
int main(){
    int y=20;
    fun(&y);
    printf("%d", y);
}
*/

//Task 4(3)
/*
int main(){
    int *ptr;
    int x;

    ptr=&x;
    *ptr=0;
    printf(" x= %d \n",x);
    printf(" *ptr = %d \n",*ptr);
    *ptr +=5;
    printf(" x= %d \n",x);
    printf(" *ptr = %d \n",*ptr);

    (*ptr)++;
    printf(" x= %d \n",x);
    printf(" *ptr = %d \n",*ptr);    
}
*/

//Task 4(d)
/*
int main(){
    float arr[5]={12.5,10.0,13.5,90.5,0.5};
    float *ptr1=&arr[0];
    float *ptr2=ptr1 +3;
    printf("%f \nn",*ptr2);
    printf("%d",ptr2 - ptr1);
}
*/

//Task5
/*
int main(){
    float num1=1,num2;
    float *fPtr=&num1;
    num2=*fPtr;
    printf("num2= %f \n",num2);
    printf("address of num1 = %p \n",fPtr);
    printf("address of pointer = %p \n",&fPtr);
}
*/

//Task 6
/*
int main(){
    float V[10]={0,1.1,2.2,3.3,4.4,5.5,6.6,7.7,8.8,9.9};
    for(int i=0;i<10;i++){
       float *Fptr=&V[i];
        printf("%f \n",V[i]);
        printf(" pointer is %d \n",Fptr);
    }
    float *Fptr=&V[0];
    printf(" +8 %f\n ",*Fptr+8);
}
*/

//Task 7
/*
int main(){
    int fno=5,sno=6;
    int *ptr=&fno,*qtr=&sno;
    printf("sum of %d and %d is %d \n",*ptr,*qtr,*ptr+*qtr);
}
*/

//Task 8
/*
int add2n(long*n1,long*n2){
    printf("%d",*n1+*n2);
}
int main(){
    int fno=5,sno=6;
    int *ptr=&fno;
    int *qtr=&sno;
    add2n(ptr,qtr);
}
*/

//Task 9
/*
int main(){
    int fno=5,sno=6;
    int *ptr=&fno,*qtr=&sno;
    if(*ptr>*qtr){
        printf(" max is %d \n",*ptr);
    }
    else{
        printf(" max is %d \n",*qtr);
    }
}
*/

//Task 10
/*
int main(){
    int x,y,z=0;
    scanf("%d %d",&x,&y);
    int *p1=&x;
    int *p2=&y;
    int *p3=&z;
    *p3=*p1;
    *p1=*p2;
    *p2=*p3;
    printf("%d %d",*p1,*p2);
}
*/

//Task 11
/*
int main(){
    int a,s=1;
    scanf("%d",&a);
    int *q=&s,*p=&a;
    for(int i=1;i<=a;i++){
        *q*=i;
    }
    printf("%d \n",*q);
}
*/

//Task 12 
/*
int main(){
    int A[5]={5,7,2,9,8};
    int sum=0,*summ=&sum;
    for(int i=0;i<5;i++){
        int *ptr=&A[i];
        *summ+=*ptr;
    }
    printf("%d \n",*summ);
}
*/

//Task 13
/*
int main(){
    int a,A[5];
    scanf("%d",&a);
    A[0]=a;
    for(int i=1;i<5;i++){
        scanf("%d",&a);
        A[i]=a;
    }
    int B[5];
    for(int i=4;i>=0;i--){
        int *p=&A[i];
        B[4-i]=*p;
    }
    for(int i=0;i<5;i++){
        printf("%d  ",B[i]);
    }
}
*/