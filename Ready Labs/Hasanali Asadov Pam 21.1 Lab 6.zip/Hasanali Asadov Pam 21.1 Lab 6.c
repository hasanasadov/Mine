#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
//Task 1
/*
int main(){
    int size;
    printf("Enter the size of array:");
    scanf("%d",&size);
    int *a=malloc(sizeof(int)*size);
    for(int i=0;i<size;i++){
        scanf("%d",&a[i]);
    }
    for(int i=0;i<size;i++){
        printf("%d ",a[i]);
    }
    printf("\n");
    a=realloc(a,size/2);
    for(int i=0;i<size/2;i++){
        printf("%d ",a[i]);
    }
    free(a);
    return 0;
}
*/

//Task 6(A)
/* 
void fun(int *p)
{
    int q=10;
    p=&q;
}

int main()
{
    int r=20;
    int *p=&r;
    fun(p);
    printf("%d",*p);
    return 0;
}
*/

//Task 6(B)
/*
int main()
{
    int a[5]={1,2,3,4,5};
    int *ptr=(int*)(&a+1);
    printf("%d %d",*(a+1),*(ptr-1));
    return 0;
}
*/

//Task 6(C)
/*
void fun(char** str_ref)
{
    str_ref++;
}

int main()
{
    char *str=(void *)malloc(100*sizeof(char));
    strcpy(str,"GeeksQuiz");
    fun(&str);
    puts(str);
    free(str);
    return 0;
}
*/

//Task 6(D)
/*
int main()
{
    int a[][3]={1, 2, 3, 4, 5, 6};
    int (*ptr)[3]=a;
    printf("%d %d \n",(*ptr)[1], (*ptr)[2]);
    ++ptr;
    printf("%d %dn",(*ptr)[1], (*ptr)[2]);
    return 0;
}
*/

//Task 6(E)
/*
int main(void)
{
    int i;
    int *ptr =(int *) malloc(5 * sizeof(int));
    for (i=0;i<5;i++){
        *(ptr + i)=i;
    }
    printf("%d ",*ptr++);
    printf("%d ",(*ptr)++);
    printf("%d ",*ptr);
    printf("%d ",*++ptr);
    printf("%d ",++*ptr);
}
*/

//Task 6(F)
/*
int fun(int arr[]){
    arr = arr+1;
    printf("%d ",arr[0]);
}

int main(void)
{
    int arr[2]={10,20};
    fun(arr);
    printf("%d",arr[0]);
    return 0;
}
*/

//Task 6(G)
/*
int f(int x,int *py,int **ppz)
{
    int y,z;
    **ppz += 1;
    z = **ppz;
    *py += 2;
    y = *py;
    x += 3;
    return x+y+z;
}

void main()
{
    int c,*b,**a;
    c=4;
    b=&c;
    a=&b;
    printf("%d", f(c,b,a));
}
*/

//Task 6(H)
/*
int main()
{
    static int a[] = {10, 20, 30 ,40 ,50};
    static int *p[] = {a, a+3, a+4, a+1, a+2};
    int **ptr = p;
    ptr++;
    printf("%d %d", ptr - p, **ptr);
}
*/

//Task 6(I)
/*
int main()
{
    unsigned int x[4][3]={{1, 2, 3}, {4, 5, 6},{7, 8, 9}, {10, 11, 12}};
    printf("%u, %u, %u",x+3,*(x+3), *(x+2)+3);
}
*/