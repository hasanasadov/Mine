#include <stdio.h>
#include <time.h>
//Task 3(a)
/*
#define SIZE 20
int main(){
    float a;
    printf("Enter number \n");
    scanf("%f",&a);
    float myrry[SIZE];
    myrry[0]=a;
    for (int i=1;i<SIZE;i++){
        printf("Enter number \n");
        scanf("%f",&a);
        myrry[i]=a;
    }
    for(int i=0; i<SIZE;i++){
        printf("%f\n",myrry[i]);
    }
}
*/

//Task 4
/*
#define n 5
int main(){
    int M[n]={1,2,3,4,5};
    for(int i=n-1;i>=0;i--){
        printf("%d \n",M[i]);
    }
}
*/

//Task 5
/*
int main(){
    int a,q=0;
    int M[6]={1,2,3,4,5,6};
    int newM[6];
    for(int i=0;i<6;i++){
        if(M[i]%2==1){
            newM[q]=M[i];
            q++;
        }
    }
    for(int z=0;z<6;z++){
        if(newM[z]!=0){
            printf("%d \n",newM[z]);
        }
    }
}
*/

//Task 6
/*
int main(){
    int Ms[10]={5,4,9,3,8,2,7,10,8,11};
    int nmin=Ms[0];
    for(int i=0;i<10;i++){
        if(Ms[i]<nmin){
            nmin=Ms[i];
        }
    }
    printf("min = %d \n",nmin);
}
*/

//Task 7
/*
int main(){
    float summ=0;
    float ave;
    int Ms[10]={5,4,9,3,8,2,7,10,8,11};
    for(int i=0;i<10;i++){
        summ+=Ms[i];
    }
    printf("average = %f / 10 = %f",summ,summ/10);
}
*/

//ARRAYI MATRIXE CEVIRMEK.
/*
void displaynumbers(int num[3][3]){
    printf("displaying:\n");
    for (int i=0;i<3;i++){
        for(int j=0;j<3;j++){
            printf("%-5d",num[i][j]);
        }
        printf("\n");
    }
}

int main(){
    int M[9]={1,2,3,4,5,6,7,8,9};
    displaynumbers(M);
    return 0;
}
*/

//Task 8
/*
int main(void){
    int array[3][3];
    int rows, columns;
    for(rows=0;rows<3;rows++){
        for(columns=0;columns<3;columns++){
                array[rows][columns]=rand()%10;
                printf("%-5d",array[rows][columns]);
            }
        printf("\n");
    }
    return 0;
}
*/

//Task 9
/*
int main(void){
    int array[3][3];
    int rows, columns;
    for(rows=0;rows<3;rows++){
        for(columns=0;columns<3;columns++){
                array[rows][columns]=rand()%10;
                printf("%-5d",array[rows][columns]);
            }
        printf("\n");
    }
    int maxx=array[0][0];
    for(rows=0;rows<3;rows++){
        for(columns=0;columns<3;columns++){
            if(array[rows][columns]>maxx){
                maxx=array[rows][columns];
            }
        }
    }
    printf("Max is %d",maxx);
}
*/

//Task 10
/*
int main(void){
    int array[3][3];
    int rows, columns;
    for(rows=0;rows<3;rows++){
        for(columns=0;columns<3;columns++){
                array[rows][columns]=rand()%10;
                printf("%-5d",array[rows][columns]);
            }
        printf("\n");
    }
    int sum=0;
    int sz=3;
    for(int i=0;i<3;i++){
        sum+=array[sz-1][i];
        sz--;
    }
    printf("sum of right diogonal = %d",sum);
}
*/

//Task 11
/*
rand();
int main(void){
    int array1[3][3];
    int rows, columns;
    printf("array 1: \n");
    for(rows=0;rows<3;rows++){
        for(columns=0;columns<3;columns++){
                array1[rows][columns]=rand()%10;
                printf("%-5d",array1[rows][columns]);
            }
        printf("\n");
    }
    printf("\n");
    printf("array 2: \n");
    int array2[3][3];
    int r,c;
    for(r=0;r<3;r++){
    for(c=0;c<3;c++){
            array2[r][c]=rand()%10;
            printf("%-5d",array2[r][c]);
        }
        printf("\n");
    }
    printf("sum of array 1 and array 2: \n");
    int array3[3][3];
    int ro,co;
    for(ro=0;ro<3;ro++){
    for(co=0;co<3;co++){
            array3[ro][co]=array1[ro][co]+array2[ro][co];
            printf("%-5d",array3[ro][co]);
        }
        printf("\n");
    }
}
*/

//Task 12
/*
void main(){
    int arr1[10][10];
    int r1,c1;
    int i, j, yn =1;
    printf("Input number of Rows for the matrix :");
    scanf("%d", &r1);
    printf("Input number of Columns for the matrix :");
    scanf("%d",&c1);   
	printf("Input elements in the first matrix :\n");
    for(i=0;i<r1;i++){
        for(j=0;j<c1;j++){
	        printf("element - [%d],[%d] : ",i,j);
	        scanf("%d",&arr1[i][j]);
        }
    }
 	printf("The matrix is :\n");
	for(i=0;i<r1;i++){
	    for(j=0;j<c1 ;j++){
	    printf("% 4d",arr1[i][j]);
        }
	    printf("\n");
	}
    for(i=0; i<r1; i++){
        for(j=0; j<c1; j++){
	        if(arr1[i][j] != 1 && arr1[j][i] !=0)
	{
	   yn = 0;
	   break;
	}
	}
}
   if(yn == 1 )
	printf(" The matrix is an identity matrix.\n\n");
   else
	printf(" The matrix is not an identity matrix.\n\n");
}
*/

//Task 13
/*
rand();
int main(){
    int A[5];
    int B[5];
    for(int i=0;i<5;i++){
        A[i]=rand()%10;
        B[i]=rand()%10;
    }
    printf("A= ");
    for(int i=0;i<5;i++){
        printf("%2d",A[i]);
    }
    printf("\n");
    printf("B= ");
    for(int i=0;i<5;i++){
        printf("%2d",B[i]);
    }
    printf("\n");
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if (A[i]==B[j]){
                printf("%d\n",A[i]);
            }
        }
    }
}
*/

//Task 15 BUBBLE SORT
/*
void swap(int* xp, int* yp){
    int temp = *xp;
    *xp = *yp;
    *yp = temp;
}
void bubbleSort(int arr[], int n){
    int i, j;
    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - i - 1; j++)
            if (arr[j] > arr[j + 1])
                swap(&arr[j], &arr[j + 1]);
}
void printArray(int arr[], int size){
    int i;
    for (i = 0; i < size; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
int main(){
    int arr[] = { 64, 34, 25, 12, 22, 11, 90 };
    int n = sizeof(arr) / sizeof(arr[0]);
    bubbleSort(arr, n);
    printf("Sorted array: \n");
    printArray(arr, n);
    return 0;
}
*/

//SELECTION SORT
/*
int main() {
    int arr[10]={6,12,0,18,11,99,55,45,34,2};
    int n=10;
    for (int i = 0; i < n; i++)
        printf("%d  ", arr[i]);
    printf("\n");
    int i, j, position, swap;
    for (i = 0; i < (n - 1); i++) {
        position = i;
        for (j = i + 1; j < n; j++) {
           if (arr[position] > arr[j])
              position = j;
        }
        if (position != i) {
           swap = arr[i];
           arr[i] = arr[position];
           arr[position] = swap;
        }
    }
    for (i = 0; i < n; i++)
        printf("%d  ", arr[i]);
    return 0;
}
*/

//QUICK SORT
/*
void swap(int *a, int *b){
  int t = *a;
  *a = *b;
  *b = t;
}
void printArray(int array[], int size){
    for (int i = 0; i < size; ++i) {
        printf("%d  ", array[i]);
    }
    printf("\n");
}
int partition(int array[], int low, int high){
    int pivot = array[high];
    int i = (low - 1);
    for (int j = low; j < high; j++) {
        if (array[j] <= pivot) {
        i++;
        swap(&array[i], &array[j]);
        }
    }
    swap(&array[i + 1], &array[high]);
    return (i + 1);
}
void quickSort(int array[], int low, int high){
    if (low < high) {
        int pi = partition(array, low, high);
        quickSort(array, low, pi - 1);
        quickSort(array, pi + 1, high);
    }
}
int main(){
    int data[] = {8, 7, 2, 1, 0, 9, 6};
    int n = sizeof(data) / sizeof(data[0]);
    printf("Unsorted Array\n");
    printArray(data, n);
    quickSort(data, 0, n - 1);
    printf("Sorted array in ascending order: \n");
    printArray(data, n);
}
*/