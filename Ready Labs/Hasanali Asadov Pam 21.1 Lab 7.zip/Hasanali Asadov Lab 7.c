#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Task 1 A
/*
struct invertory
{
    char partName[30];
    int partNumber;
    float pointPrice;
    int stock;
    int reorder; 
};
*/

//Task 1 B
/*
struct address
{
    char streetAdress[25];
    char city[20];
    char state[3];
    char zipCode[6];
};
*/

//Task 1 C
/*
struct invertory
{
    char firstName[15];
    char LastName[15];
    struct address homeAdress;
};
*/

//Task 2
struct customer 
{
    char lastName[15];
    char firstName[15];
    unsigned int customerNumber;
    struct {
        char phoneNumber[11];
        char address[50];
        char address[50];
        char city[15];
        char state[3];
        char zipCode[6];
    } personal;
} customerRecord, *customerPtr;
customerPtr = &customerRecord;

int main()
{
    costumerRecord.lastName;
    customerPtr->lastName or (*customerPtr).lastName;
    customerRecord.firstName;
    customerPtr->firstName or (*customerPtr).firstName;
    customerRecord.customerNumber;
    customerPtr->customerNumber or (*customerPtr).customerNumber;
    customerRecord.personal.phoneNumber;
    customerPtr->personal.phoneNumber or (*customerPtr).personal.phoneNumber;
}