#include <stdio.h>
#include <math.h>
//Task2 EVEN OR ODD FUNCTION
/*
void isEven();
int main(){
    int q;
    scanf("%d",&q);
    while (q!=-1){
        isEven(q);
        scanf("%d",&q);
    }
}

void isEven(int q){
    if (q%2==0){
        printf("even\n");
        }
    else{
        printf("odd\n");
        }
}
*/

//Task3 MULTPY OF DIGITS
/*
void MultipleDigit();
int main(){
    int a;
    scanf("%d",&a);
    MultipleDigit(a);
}
void MultipleDigit(int a){
    int s=1;
    while (a>0){
        s*=a%10;
        a/=10;
    }
    printf("%d",s);
}
*/

//Task 4
/*
void FtoC();
int main(){
    FtoC();
}
void FtoC(){
    float c,f;
    scanf("%f",&f);
    c=((f-32)*5)/9;
    printf("%f\n",c);
}
*/

//Task 5 FACTORIAL WITH RECURSION
/*
int fact(int a){
    if (a>=2){
        return a*fact(a-1);
    }
    else
        return 1;
}
int main(){
    int a;
    printf("enter the number\n");
    scanf("%d",&a);
    printf("the factorial of %d is %d",a,fact(a));
}
*/

//Task 6
/*
double main(){
    printf("%f",fabs(10,85));
    printf("%f",floor(10,85));
    printf("%f",fabs(–0,678));
    printf("%lf",ceil(9,234));
    printf("%f",fabs(0,0));
    printf("%lf",ceil(–34,87));
    printf("%f",ceil(-fabs(–12-floor(–9,5))));
    return 0;
}
*/

//Task7 CALCULATING HYPTONUS
/*
int hyp(int a,int b){
    float c;
    c=sqrt(a*a+b*b);
    return c;
}
int main(){
    int a,b;
    printf("enter A=");
    scanf("%d",&a);
    printf("enter B=");
    scanf("%d",&b);
    printf("%lf\n",hyp(a,b));
}
*/

//Task8 AREA OF TRIGLE
/*
#include <stdio.h>
#include <math.h>
int area(int a,int b,int c){
    float A,p;
    p=(a+b+c)/2;
    A=sqrt(p*(p-a)*(p-b)*(p-c));
    printf("%f",A);
}
int main(){
    int a,b,c;
    printf("Enter sides of triange by using space");
    scanf("%d %d %d",&a,&b,&c);
    if ((a+b)<c && abs(a-b)>c) && ((a+c)<b && abs(a-c)>b) && ((c+b)<a && abs(c-b)>a){
            printf("%f",area(a,b,c));
    }
    else{
        printf("there is not a such a triange")
    }
}
*/

//Task 9 STAR TABLE
/*
int star(int a,int b){
    while (a!=0){
        int t=b;
        while(t!=0){
            printf("*");
            t--;
        }
        printf("\n");
        a--;
    }
}
int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    printf("%c",star(a,b));
}
*/

//Task 10 CHAR TABLE
/*
char sym(int a,int b,char c){
    while (a!=0){
        int t=b;
        while(t!=0){
            printf("%c",c);
            t--;
        }
        printf("\n");
        a--;
    }
}
int main(){
    int a,b;
    char c;
    printf("enter row col symbol\n");
    scanf("%d %d %c",&a,&b,&c);
    printf("%c",sym(a,b,c));
}
*/

//Task 11(a) USD TO YEN
/*
double toYen(double y){
    printf("%lf",y*118.87);
}
int main(){
    double y;
    printf("enter USD\n");
    scanf("%lf",&y);
    toYen(y);
}
*/

//Task 11(b) USD TO EURO
/*
double toEuro(double e){
    printf("%lf",e*0.92);
}
int main(){
    double e;
    scanf("%lf",&e);
    printf("%lf USD = %lf Euro",e,toYen(e));
}
*/

//Task 11(c)CURRENNCY CONVERTER TABLE
/*
double toYen(double y){
    return y*118.87;
}
double toEuro(double e){
    return e*0.92;
}
int main(){
    int a,b;
    printf("enter range");
    scanf("%d %d",&a,&b);
    printf("USD      YEN      EURO\n");
    for(int u=a;u<=b;u++){
        printf("%d      %lf      %lf\n",u,toYen(u),toEuro(u));
    }
}
*/

//Task 12 SUM OF DIGITS
/*
int sumdig(int a){
    int c=0;
    while (a>0){
        c+=a%10;
        a/=10;
    }
    return c;
}
int main(){
    int a;
    printf("Enter the number");
    scanf("%d",&a);
    printf("sum of digits of %d is %d",a,sumdig(a));
}
*/

//Task 13 LCM
/*
int lcm(int a,int b){
    int maxx,q,lcm;
    if (a>b)
        maxx=a;
    else
        maxx=b;
    q=maxx;
    while(q!=1){
        if (q%a==0 && q%b==0){
            lcm=q;
            break;
        }
        else
            q++;
    }
    return lcm;
}
int main(){
    int a,b;
    printf("enter a b \n");
    scanf("%d %d",&a,&b);
    printf("LCM is %d ",lcm(a,b));
}
*/
//Task 14 MARKING
/*
int a4(int a){
    if (a<=100 && a>=90){
        printf("4");
    }
}
int a3(int a){
    if (a<=89 && a>=80){
        printf("3");
    }
}
int a2(int a){
    if (a<=79 && a>=70){
        printf("2");
    }
}
int a1(int a){
    if (a<=69 && a>=60){
        printf("1");
    }
}
int a0(int a){
    if (a<60){
        printf("0");
    }
}
int main(){
    int a;
    printf("enter score \n");
    scanf("%d",&a);
    a1(a);
    a2(a);
    a3(a);
    a4(a);
    a0(a);
}
*/

//Task 15 PERFECT NUMBER
/*
int sumofdivide(int x){
    int c,summ=0;;
    for (int c=1;c<x;c++){
        if (x%c==0){
            summ+=c;
        }
    }
    return summ;
}
int main(){
    int a;
    printf("Till which number ");
    scanf("%d",&a);
    for(int q=1;q<a;q++){
        if (sumofdivide(q)==q){
            printf("%d\n",q);
        }
    }
}
*/

//Task 16 FINDING OF ROOTS
/*
int discr(int a,int b,int c){
    int d;
    d=b*b-4*a*c;
    return d;
}
int roots(int a,int b){
    float x1,x2;
    double d;
    x1=(-b-sqrt(d))/2*a;
    x2=(-b+sqrt(d))/2*a;
    printf("x1 = %f ",x1);
    printf("x2 = %f ",x2);
}
int main(){
    int a,b,c;
    printf("enter a b c \n");
    scanf("%d %d %d",&a,&b,&c);
    if (discr(a,b,c)>=0){
        roots(a,b);
    }
    else{
        printf("there is not root");
    }
}
*/

//Task 17 FINDING THE NUMBER
/*
#include <time.h>
#include <stdlib.h>
int main(){
    int a;
    time_t t;
    srand((unsigned)time(&t));
    a=rand()%1000;
    int c;
    printf("i have a number between 1 and 1000\n");
    printf("Can you find it\n");
    scanf("%d",&c);
    while (c!=a){
        if (c>a){
            printf("write Lower\n");
        }
        else{
            printf("write Higher\n");
        }
        scanf("%d",&c);
    }
    printf("you find the number!!!\n");
    printf("The number was %d ",a);
}
*/

//Task 18 POWER OF NUMBER
/*
int power(int a,int b){
    if (b>2){
        return a*power(a,b-1);
    }
    else
        return a;
}
int main(){
    int a,b;
    printf("enter a b (first number then power)");
    scanf("%d %d",&a,&b);
    printf("%d",power(a,b));
}
*/
