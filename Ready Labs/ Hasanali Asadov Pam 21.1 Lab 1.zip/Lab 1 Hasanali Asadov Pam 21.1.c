#include <stdio.h>
//Task2

/**
int main()
{
    int u,a,t;
    printf("enter u a t:\n");
    scanf("%d %d %d",&u,&a,&t);
    printf("v=%d\n",u+a*t);
    printf("s=%.2f\n",u*t+0.5*a*t*t); // 2f sondan 2 eded saxlamq 
} **/


//Task 3
/**
int main()
{
    int a,b,c,maxx,minn;
    printf("enter a b c :\n");
    scanf("%d %d %d",&a,&b,&c);
    printf("summ is %d",a+b+c);
    printf("averagee is %.2f",(a+b+c)/3);
    printf("productt is %d",a*b*c);
    if (a>=b && a>=c)
    {
        maxx=a;
        if(b>=c)
          minn=c;
        else
          minn=b;
    }
      
    else if (b>=a && b>=c) 
    {
        maxx=b;
        if(a>=c)
          minn=c;
        else
          minn=a;
    }
       
    else (c>=a && c>=b)
    {
        maxx=c;
        if(a>=b)
          minn=b;
        else
          minn=a;   
    }
    printf("largest = %d smallest id %d",&maxx,&minn);
       
}
**/

//Task4(2)
/**
#include <stdio.h>

int main() {
  int a,s,m,h;
  printf("enter seconds\n");
  scanf("seconds=%d", &a);
  s=a;
  m=0;
  h=0;
  while (s>=60);
      s/=60;
      m+=1;
      printf("%d\n", &m);
  while (m>=60);
      m/=60;
      h+=1;
  printf("hour=%d minute=%d second=%d\n", &h, &m, &a);
}
**/

//Task 4
/**
int main()
{
  int sec,hs,ms,sec2;
  printf("sec=%d\n");
  scanf("%d",&sec);
  hs=sec*3600;
  ms=(sec-(hs*3600))/60;
  sec2=(sec-hs*3600)%60;
  printf("hs=%d\n",hs);
  printf("minutes=%d\n",ms);
  printf("sec2=%d\n",sec2);
}
**/

//Task5
/**
 int main()
{
    printf("*\n**\n***\n****\n*****\n");\
}
**/

//Task 6
/**
int main(){
  int a,b,c;
  b=a*60;
  c=a*3600;
  printf("hours minutes seconds\n");
  scanf("h=%d", &a);
  printf("%ls %ls %ls",a,b,c);
  return 0;
}
**/

//Task 7
/**
 #include <stdio.h>

int main()
{
    int a,b;
    printf("enter a b:\n");
    scanf("%d %d",&a,&b);
    if(a%b==0){
        printf("is");
    }
    else{
        printf("is not");
    }
    return 0;
}


//Task 8

int main()
{
  int x,a,b,c,d,e;
  printf("eded:");
  scanf("%d",&x);
  a=x/10000;
  b=(x/1000)%10;
  c=(x/100)%10;
  d=(x/10)%10;
  e=x%10;
  printf("%d %d %d %d %d",a,b,c,d,e);
}


//Task 9
/**
int main()
{
  int a,b,temp;
  printf("ededleri daxil et");
  scanf("%d %d",&a,&b);
  t=a;
  a=b;
  b=t;
  printf("next:%d,%d",a,b);
}
**/
